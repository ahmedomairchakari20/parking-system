<?php

$con=mysqli_connect("localhost","root","","parking") OR die('Network connection error. Check connection then reload');
/*
$con=mysqli_connect("localhost","root","pass123","users") OR die('Network connection error. Check connection then reload');
*/
 ?>
